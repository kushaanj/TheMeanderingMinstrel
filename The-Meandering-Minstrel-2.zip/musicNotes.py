import pygame
import multiprocessing
import time

castleInTheSkyNotes = ["d", "e", "fff", "e", "ff", "aa", "eeee", "66", "ddd", "c", "dd", "ff", "cccc"]
castleInTheSkyTime = ["1000", "1000", "3000", "1000", "2000", "2000", "6000", "2000", "3000", "1000", "2000", "2000", "4000"]

def printSheetMusic(musicNotes, musicTime):
    for i in range(len(musicNotes)):
        print(musicNotes[i])
        time.sleep(int(musicTime[i])/1000)

def playerDamage(playingNote, userPlayedNote, monsterHP):
    if userPlayedNote == playingNote:
        print("Player Dealt 500 Damage!")
        monsterHP -= 500
        return monsterHP

    else:
        print("You missed!")
        return monsterHP

def findNotePlaying(elapsedTime, musicTime, musicNote):
    songPlayedTime = 0
    for i in range(len(musicTime)):
        songPlayedTime += int(musicTime[i])
        if elapsedTime < songPlayedTime:
            return musicNote[i]


print("\nBattle Start.")
print("\nCastle In The Sky ♪ ~")
pygame.mixer.init()
pygame.mixer.music.load("castleInTheSky.mp3")
pygame.mixer.music.play()

sheetMusic = multiprocessing.Process(target= printSheetMusic, args=(castleInTheSkyNotes, castleInTheSkyTime))

monsterHP = 5000
noteNumber = 0
loopCounter = 0

while loopCounter == 0:
    userInput = input("")
    pygame.mixer.music.stop()
    if userInput == "start":
        print(r"""
              _          _
             _/|    _   |\_
           _/_ |   _|\\ | _\
         _/_/| /  /   \|\ |\_\_
       _/_/  |/  /  _  \/\|  \_\_ 
     _/_/    ||  | | \o/ ||    \_\_
    /_/  | | |\  | \_ V  /| | |  \_\
   //    ||| | \_/   \__/ | |||    \\
  // __| ||\  \          /  /|| |__ \\
 //_/ \|||| \/\\        //\/ ||||/ \_\\
///    \\\\/   /        \   \////    \\\
|/      \/    |    |    |     \/      \|
              /_|  | |_  \
             ///_| |_||\_ \
             |//||/||\/||\|             'I SERVE THE SOVIET UNION"
              / \/|||/||/\/                     
                /|/\| \/                            -PHOENIX
                \/  |                          
        """)
        print("A wild communist phoenix appeared.")
        time.sleep(3)
        start_time = time.time()
        sheetMusic.start()
        printSheetMusic(castleInTheSkyNotes, castleInTheSkyTime)

    if userInput == "end":
        print("Game End.")
        sheetMusic.terminate()
        break

    try:
        note = userInput[0] + ".mp3"
    except IndexError:
        print("", end="")

    if userInput != "start":
        if len(userInput) == 1: #sixteenth note
            try:

                pygame.mixer.music.load(note)
                pygame.mixer.music.play()
                pygame.mixer.music.fadeout(800)
                #time.sleep(1)
            except pygame.error:
                print("Note not found.")

        elif len(userInput) == 2: #quarter note
            try:
                pygame.mixer.music.load(note)
                pygame.mixer.music.play()
                pygame.mixer.music.fadeout(1600)
                #time.sleep(2)
            except pygame.error:
                print("Note not found.")

        elif len(userInput) == 3: #1.5 Quarter note
            try:
                pygame.mixer.music.load(note)
                pygame.mixer.music.play()
                pygame.mixer.music.fadeout(2400)
                #time.sleep(3)
            except pygame.error:
                print("Note not found.")

        elif len(userInput) == 4: #half note
            try:
                pygame.mixer.music.load(note)
                pygame.mixer.music.play()
                pygame.mixer.music.fadeout(3200)
                #time.sleep(4)
            except pygame.error:
                print("Note not found.")

        elif len(userInput) == 5: #whole note
            try:
                pygame.mixer.music.load(note)
                pygame.mixer.music.play()
                pygame.mixer.music.fadeout(6400)
            except pygame.error:
                print("Note not found.")

        elapsed_time = time.time() - start_time
        elapsed_time = int(round(elapsed_time * float(1000), 0))
        notePlaying = findNotePlaying(elapsed_time, castleInTheSkyTime, castleInTheSkyNotes)
        monsterHP = playerDamage(notePlaying, userInput, monsterHP)

    """
    if monsterHP <= 0:
        print("\nYou won!"
              "\nThe communist phoenix fainted.")
        sheetMusic.terminate()
        break

    if sheetMusic.is_alive() == False and monsterHP > 0:
        print("\nYou are defeated."
              "\nNow you are a proud communist."
              "\nAll you properties are equally distributed to all citizens.")
        sheetMusic.terminate()
        break
    """