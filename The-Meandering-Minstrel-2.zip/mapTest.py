class Person:

    def __init__(self, name: Str):
        self.name = name
        self.friends = Set()
        self.HP = Int
        self.id = Int
        self.attack = Int
        self.level = Int
        self.location = Str

    def getName(self) -> Str:
        return self.name

    def getFriends(self) -> Set[Person]:
        return self.friends

    def getHP(self) -> Int:
        return self.HP

    def getID(self) -> Int:
        return self.id

    def getAttack(self) -> Int:
        return self.attack

    def getLevel(self) -> Int:
        return self.level

    def getLocation(self) -> Str:
        return self.location

    def setName(self, name: Str):
        self.name = name

    def addFriend(self, person: Person):
        self.friends.add(person)

    def removeFriend(self, person: Person):
        self.friends.remove(person)

    def setHP(self, HP: Int):
        self.HP = HP

    def setID(self, ID: Int):
        self.id = ID

    def setAttack(self, attack: Int):
        self.attack = attack

    def setLevel(self, level: Int):
        self.level = level

    def setLocation(self, location: Str):
        self.location = location


AREANAME = "Name"
DESCRIPTION = 'description'
UP = 'up', 'north'
DOWN = 'down', 'south'
LEFT = 'left', 'west'
RIGHT = 'right', 'east'

"""

Example of the Map:

[a1] [a2] [a3]
[b1] [b2] [b3]
[c1] [c2] [c3]


"""
zoneMap = {
    'a1': {AREANAME: "Midgard",
           DESCRIPTION: 'The realm of all us puny mortals, From here to seven realms be portals',
           UP: None, DOWN: 'b1',
           LEFT: None, RIGHT: 'a2'
           },

    'a2': {AREANAME: "Alfheim",
           DESCRIPTION: "Here is a land, once of great cheer and light, Now falling into never ending night,",
           UP: None, DOWN: 'b2',
           LEFT: 'a1', RIGHT: 'a3'
           },

    'a3': {AREANAME: "Nidavellir",
           DESCRIPTION: 'The home of the dwarves, a most stout of folk, Now falling into ruin, ready to croak.',
           UP: None, DOWN: 'b3',
           LEFT: 'a2', RIGHT: None
           },

    'b1': {AREANAME: "Jotunheim",
           DESCRIPTION: 'The realm of giants, foes ten feet tall. If my luck holds true, I’ll never face them at all.',
           UP: 'a1', DOWN: 'c1',
           LEFT: None, RIGHT: 'b2'
           },

    'b2': {AREANAME: "Svartalfheim",
           DESCRIPTION: 'The home of all the villainous dark elves: a place so dangerous that no one delves.',
           UP: 'a2', DOWN: 'c2',
           LEFT: 'b1', RIGHT: 'b3'
           },

    'b3': {AREANAME: "Niflheim",
           DESCRIPTION: 'Land of dread and horrifying dead: to pass through I must win through bloodshed.',
           UP: 'a3', DOWN: 'c3',
           LEFT: 'b2', RIGHT: None
           },

    'c1': {AREANAME: "Vanaheim",
           DESCRIPTION: 'Home of Vanir, the weaker of Gods, against even them, I don’t like my odds.',
           UP: 'b1', DOWN: None,
           LEFT: None, RIGHT: 'c2'
           },

    'c2': {AREANAME: "Asgard",
           DESCRIPTION: 'Plane of Aesir, whose powers amaze and shock, at least they used to, before Ragnorok.',
           UP: 'b2', DOWN: None,
           LEFT: 'c1', RIGHT: 'c3'
           },

    'c3': {AREANAME: "Muspelheim",
           DESCRIPTION: 'Realm of the forces of great and feared Loki, here all must bow before the trickster gods decree',
           UP: 'b3', DOWN: None,
           LEFT: 'c2', RIGHT: None
           }
}

playerName = "Kush"  # Add option to change name later

playerChoice = None


def pickDirection(playerName, zoneMap, playerChoice):
    userPlaying = Person(playerName)

    playerChoice = input("Do you want to move left, right, up or down? ")

    while str(playerChoice.lower) != (str(left) or str(right) or str(up) or str(down)):
        playerChoice = input("Please try again with the correct direction")

    userCurrentLocation = str(userPlaying.getLocation())

    locationInformation = zoneMap.get(str(userCurrentLocation))

    return locationInformation


locationInformation = pickDirection(playerName, zoneMap)

validDirection = False

while validDirection == False:

    if str(playerChoice.lower()) == str(left):

        if locationInformation.get(LEFT) == None:
            validDirection = False
            print("You cannot go left from here. Please pick another direction")
            locationInformation = pickDirection(playerName, zoneMap, playerChoice)

        else:
            userPlaying.setLocation(locationInformation.get(LEFT))
            validDirection = True

    elif str(playerChoice.lower()) == str(right):
        if locationInformation.get(RIGHT) == None:
            validDirection = False
            print("You cannot go right from here. Please pick another direction")
            locationInformation = pickDirection(playerName, zoneMap, playerChoice)

        else:
            userPlaying.setLocation(locationInformation.get(RIGHT))
            validDirection = True

    elif str(playerChoice.lower()) == str(up):
        if locationInformation.get(UP) == None:
            validDirection = False
            print("You cannot go up from here. Please pick another direction")
            locationInformation = pickDirection(playerName, zoneMap, playerChoice)

        else:
            userPlaying.setLocation(locationInformation.get(UP))
            validDirection = True

    elif str(playerChoice.lower()) == str(down):
        if locationInformation.get(DOWN) == None:
            validDirection = False
            print("You cannot go down from here. Please pick another direction")
            locationInformation = pickDirection(playerName, zoneMap, playerChoice)

        else:
            userPlaying.setLocation(locationInformation.get(DOWN))
            validDirection = True