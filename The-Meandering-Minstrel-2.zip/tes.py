list = "haha lol"
list = list.replace("haha", "lol")
print(list)