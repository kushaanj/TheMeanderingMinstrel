import json

class Person:

    def __init__(self, name = "", HP = 500, id = 1, attack = 50,
                 level = ["castleInTheSky"], location = "a1"):
        self.name = name
        self.HP = HP
        self.id = id
        self.attack = attack
        self.level = level
        self.location = location

    def getName(self):
        return self.name

    def setName(self, name: str):
        self.name = name

    def getHP(self):
        return self.HP

    def setHP(self, HP: int):
        self.HP = HP

    def getID(self):
        return self.id

    def setID(self, ID: int):
        self.id = ID

    def getAttack(self):
        return self.attack

    def setAttack(self, attack: int):
        self.attack = attack

    def getLevel(self):
        return self.level

    def addLevel(self, music):
        self.level.append(music)

    def setLevel(self, levels):
        self.level = levels

    def getLocation(self):
        return self.location

    def setLocation(self, location: str):
        self.location = location

    def setPlayer(self, ID, player):
        question = "\n           What doth thee liketh to beest hath called?"
        """
        for i in range(len(question)):
            print(question[i], end="")
            time.sleep(0.05)
        """
        print(question)
        playerInput = input("           >")
        player.setName(playerInput)
        player.setID(ID)

        """
        introduction = "              On this weary road, i wend: a bard, high-lone and penniless. " \
                       "\n              Some wouldst wond'r wherefore a bard wouldst ev'r decideth " \
                       "\n              to traveleth without any supp'rt to speaketh of.  " \
                       "\n              While we bards art naturally charming and devilishly handsome, " \
                       "\n              the savages in the adventur'rs’ guild seemeth to has't taken umbrage " \
                       "\n              with mine own startling humility and thus i wilt traveleth high-lone," \
                       "\n              out into the unknown.  " \
                       "\n              I shall proveth all the adventur'rs wrong at which hour " \
                       "\n              i reacheth the true heights of pow'r, " \
                       "\n              f'r i seeketh an artifact of unimaginable pow'r.  " \
                       "\n              I traveleth to the realm of chaos, muspelheim, wh're the l're of ancients awaits.  " \
                       "\n              Mine own charm is stout, but i knoweth not what mann'r of savag'ry, s'rc'ry, " \
                       "\n              'r skuldugg'ry awaits, and i only desire yond i can in timeth groweth " \
                       "\n              stout enow to visage the dunnest t'rr'rs enshielf in these ravag'd realms."
        print("\n           The bard " + playerInput + " sayeth:\n")
        for i in range(len(introduction)):
            print(introduction[i], end="")
            time.sleep(0.05)
        """

class Nodes:
    def __init__(self, data: Person):
        self.parent = None
        self.left = None
        self.right = None
        self.data = data

    def getData(self):
        return self.data

    def getDataID(self):
        return self.data.getID()

    def getLeftNode(self):
        return self.left

    def setLeftNode(self, node):
        self.left = node

    def getRightNode(self):
        return self.right

    def setRightNode(self, node):
        self.right = node

    def setParent(self, node):
        self.parent = node

def insertNode(tempParent, InsertNode):
    if InsertNode.getDataID() < tempParent.getDataID():
        if tempParent.getLeftNode() == None:
            InsertNode.setParent(tempParent)
            tempParent.setLeftNode(InsertNode)
        else:
            insertNode(tempParent.getLeftNode(), InsertNode)

    else:
        if tempParent.getRightNode() == None:
            InsertNode.setParent(tempParent)
            tempParent.setRightNode(InsertNode)
        else:
            insertNode(tempParent.getRightNode(), InsertNode)

def searchNode(parentNode: Nodes, searchID: int):
    if searchID < parentNode.getDataID():
        if parentNode.getLeftNode() == None:
            print("\nPerson not found.")

        elif parentNode.getLeftNode().getDataID() == searchID:
            return parentNode.getLeftNode().getData()

        else:
            searchNode(parentNode.getLeftNode(), searchID)

    elif searchID == parentNode.getDataID():
        return parentNode.getData()

    else:
        if parentNode.getRightNode() == None:
            print("\nPerson not found.")

        elif parentNode.getRightNode().getDataID() == searchID:
            return parentNode.getRightNode().getData()

        else:
            searchNode(parentNode.getRightNode(), searchID)

def saveBinaryTree (root, list): #saving binary trees branch by branch from left to right
    list.append(root.getData())
    if root.getLeftNode() != None:
        saveBinaryTree(root.getLeftNode(), list)
    if root.getRightNode() != None:
        saveBinaryTree(root.getRightNode(), list)
    return list

def readFromFile(userDatabase):
    f = open("game.txt", "r+")
    data = f.readlines()
    index = 0

    rootID = int(round(len(data)/2))
    rootIndex = -1

    for line in data:

        items = line.split(",")
        userDatabase.append(Person())
        userDatabase[index].setName(items[0])
        userDatabase[index].setHP(int(items[1]))
        userDatabase[index].setID(int(items[2]))
        userDatabase[index].setAttack(int(items[3]))
        list = json.loads(items[4])
        userDatabase[index].setLevel(list)
        userDatabase[index].setLocation(items[5])
        if int(userDatabase[index].getID()) == rootID:
            root = Nodes(userDatabase[index])
            rootIndex = index
        index += 1

    userDatabase.remove(userDatabase[rootIndex])
    f.close()
    return [userDatabase, root]

def writeToFile(userDatabase):

    f = open("game.txt", "w+")

    for x in range(len(userDatabase)):
        string = json.dumps(userDatabase[x].getLevel())
        f.write(userDatabase[x].getName() + "," + str(userDatabase[x].getHP()) + "," +
                str(userDatabase[x].getID()) + "," + str(userDatabase[x].getAttack()) + "," +
                str(string) + "," + userDatabase[x].getLocation())

    f.close()

def listToBinaryTree(userDatabase, root):
    for i in range(len(userDatabase)):
        InsertNode = Nodes(userDatabase[i])
        insertNode(root, InsertNode)

    return root


userReadDatabase = []
returnList = readFromFile(userReadDatabase)
userReadDatabase = returnList[0]
root = returnList[1]
root = listToBinaryTree(userReadDatabase, root)
userReadDatabase = None
print(root.getData().getName(), root.getDataID())

userWriteDatabase = []
userWriteDatabase = saveBinaryTree(root, userWriteDatabase)
writeToFile(userWriteDatabase)