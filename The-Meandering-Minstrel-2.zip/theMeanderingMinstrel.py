import time
import pygame
import sys
import multiprocessing
import random
import json

#music library
castleInTheSky = "music for lv1"
castleInTheSkyNotes = ["d", "e", "fff", "e", "ff", "aa", "eeee", "66", "ddd", "c", "dd", "ff", "cccc"]
castleInTheSkyTime = ["1000", "1000", "3000", "1000", "2000", "2000", "6000", "2000", "3000", "1000", "2000", "2000", "4000"]

jingleBell = "music for lv3"
jingleBellNotes = ["ee", "ee", "eeee", "ee", "ee", "eeee", "ee", "gg", "cc", "dd", "eeeee", "ff", "ff", "fff", "f", "ff", "ee", "ee"]
jingleBellTime = ["2000", "2000", "4000", "2000", "2000", "4000", "2000", "2000", "3000", "1000", "8000", "2000", "2000", "3000", "1000", "2000", "2000", "2000"]

thisOldMan = "music for lv2"
thisOldManNotes = ["gg", "ee", "gggg", "gg", "ee", "gggg", "aa", "gg", "ff", "ee", "dd", "ee", "ff", "e", "f"]
thisOldManTime = ["2000", "2000", "4000", "2000", "2000", "4000", "2000", "2000", "2000", "2000", "2000", "2000", "2000", "1000", "1000"]

musicLibrary = {
    "castleInTheSky": [castleInTheSkyNotes, castleInTheSkyTime],
    "thisOldMan": [thisOldManNotes, thisOldManTime],
    "jingleBell": [jingleBellNotes, jingleBellTime]
}

musicNames = ["castleInTheSky", "thisOldMan", "jingleBell", "randomMusic"]

backGroundMusic = ["lamentOfTheRohirrrim", "lamentOfBoromir", "theDragonIsWithered"]


class Person: #class for player

    def __init__(self, name = "", HP = 500, id = 1, attack = 50,
                 level = ["castleInTheSky"], location = "a1"):
        self.name = name #name of player
        self.HP = HP #hp of player
        self.id = id #id of player
        self.attack = attack #attack of player
        self.level = level #level of player. the length of this list indicates your level,
        # while the content indicate what music the player can play while battling a monster
        self.location = location #location of player

    def getName(self):
        return self.name

    def setName(self, name: str):
        self.name = name

    def getHP(self):
        return self.HP

    def setHP(self, HP: int):
        self.HP = HP

    def getID(self):
        return self.id

    def setID(self, ID: int):
        self.id = ID

    def getAttack(self):
        return self.attack

    def setAttack(self, attack: int):
        self.attack = attack

    def getLevel(self):
        return self.level

    def addLevel(self, music):
        self.level.append(music)

    def setLevel(self, levels):
        self.level = levels

    def getLocation(self):
        return self.location

    def setLocation(self, location: str):
        self.location = location

    def setPlayer(self, ID, player): #a function to setup a player at the start of the game
        question = "\n           What do you like to be called?"
        for i in range(len(question)):
            print(question[i], end="")
            time.sleep(0.05)

        playerInput = input("\n           >")
        player.setName(playerInput)
        player.setID(ID)

        introduction = "              On this weary road, I go: a bard, alone and penniless."\
               "\n              Some would wonder why a bard would ever decide to travel" \
               "\n              without any support to speak of. " \
               "\n              While we bards are naturally charming and devilishly handsome, " \
               "\n              the savages in the Adventurers’ Guild seem to have taken umbrage " \
               "\n              with my startling humility and thus I must travel alone out into the unknown." \
               "\n              I will prove all the adventurers wrong when I reach the true heights of power," \
               "\n              for I seek an artifact of unimaginable strength. " \
               "\n              f'r i seeketh an artifact of unimaginable pow'r.  " \
               "\n              I shall travel to the realm of chaos, Muspelheim, where the lore of ancients awaits." \
               "\n              My music is strong, but I know not what manner of savagery, sorcery, " \
               "\n              or skulduggery awaits, and I only hope that I can in time grow strong enough " \
               "\n              to face the darkest terrors hidden in these ravaged realms. "

        print("\n           The bard " + playerInput + " says:\n")
        for i in range(len(introduction)):
            print(introduction[i], end="")
            time.sleep(0.03)

class Monster: #class for monster
    def __init__(self, name = "", HP = 500, attack = 50, lines = [], picture = r""""""):
        self.name = name #monster name
        self.HP = HP #monster hp
        self.attack = attack #monster attack
        self.lines = lines #what monster speak.
        self.picture = picture #picture of monster

    def getName(self):
        return self.name

    def getHP(self):
        return self.HP

    def getAttack(self):
        return self.attack

    def setName(self, name: str):
        self.name = name

    def setHP(self, HP: int):
        self.HP = HP

    def setAttack(self, attack: int):
        self.attack = attack

    def addLines(self, line):
        self.lines.append(line)

    def getLines(self):
        return self.lines

    def setLines(self, lines):
        self.lines = lines

    def getPic(self):
        return self.picture

    def setPic(self, picture):
        self.picture = picture


def startAnimation(): #scroll unrolling printed out at the start of the game
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
    print("""\
    .-=~=-. .-=~=-.
    (__  _)-(__  _) 
    ( _ __) ( _ __)
    (__  _) (__  _)
    (_ ___) (_ ___)
    (__  _) (__  _)
    ( _ __) ( _ __)
    (__  _) (__  _)
    (_ ___) (_ ___)
    (__  _) (__  _)
    ( _ __) ( _ __)
    (__  _) (__  _)
    (_ ___) (_ ___)
    (__  _) (__  _)
    ( _ __) ( _ __)
    (__  _) (__  _)
    (_ ___) (_ ___)
    (__  _) (__  _)
    ( _ __) ( _ __)
    (__  _) (__  _)
    ( _ __) ( _ __) 
    (__  _) (__  _)
    (_ ___)-(_ ___)
    `-._.-' `-._.-'
    """)
    time.sleep(1)
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
    print("""\
    .-=~=-.                                .-=~=-.
    (__  _)-._.-=-._.-=-._.-=-._.-=-._.-=-.(__  _) 
    ( _ __)                                ( _ __)
    (__  _)                                (__  _)
    (_ ___)                                (_ ___)
    (__  _)                                (__  _)
    ( _ __)                                ( _ __)
    (__  _)                                (__  _)
    (_ ___)                                (_ ___)
    (__  _)                                (__  _)
    ( _ __)                                ( _ __)
    (__  _)                     The Meander(__  _)
    (_ ___)                                (_ ___)
    (__  _)                                (__  _)
    ( _ __)                                ( _ __)
    (__  _)                                (__  _)
    (_ ___)                                (_ ___)
    (__  _)                                (__  _)
    ( _ __)                                ( _ __)
    (__  _)                                (__  _)
    ( _ __)                                ( _ __)
    (__  _)                                (__  _)
    (_ ___)-._.-=-._.-=-._.-=-._.-=-._.-=-.(_ ___)
    `-._.-'                                `-._.-'
    """)
    time.sleep(1)
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
    print("""\
    .-=~=-.                                                                 .-=~=-.
    (__  _)-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-(__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                                                                 (__  _)
    (_ ___)                                                                 (_ ___)
    (__  _)                                                                 (__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                                                                 (__  _)
    (_ ___)                                                                 (_ ___)
    (__  _)                                                                 (__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                     The Meandering Minstrel                     (__  _)
    (_ ___)                                                                 (_ ___)
    (__  _)                                                                 (__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                                                                 (__  _)
    (_ ___)                                                                 (_ ___)
    (__  _)                                                                 (__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                                                                 (__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                                                                 (__  _)
    (_ ___)-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-(_ ___)
    `-._.-'                                                                 `-._.-'
    """)
    time.sleep(7)


def startMenu(): #the printed out starting menu
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
    print("""\
    .-=~=-.                                                                 .-=~=-.
    (__  _)-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-(__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                                                                 (__  _)
    (_ ___)                                                                 (_ ___)
    (__  _)                                                                 (__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                                                                 (__  _)
    (_ ___)                     The Meandering Minstrel                     (_ ___)
    (__  _)                                                                 (__  _)
    ( _ __)                              Start                              ( _ __)
    (__  _)                              Help                               (__  _)
    (_ ___)                              Quit                               (_ ___)
    (__  _)                                                                 (__  _)
    ( _ __)                           Version 1.0                           ( _ __)
    (__  _)                                                                 (__  _)
    (_ ___)                                                                 (_ ___)
    (__  _)                                                                 (__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                                                                 (__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                                                                 (__  _)
    (_ ___)-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-(_ ___)
    `-._.-'                                                                 `-._.-'
    """)


def menuChoose(): #the choice at the title screen of the game
    startChoose = input("           >")
    if startChoose.lower() == "start":
        print("", end="")

    elif startChoose.lower() == "help":
        helpMenu()

    elif startChoose.lower() == "quit":
        print("           Game End.")
        sys.exit()

    while startChoose.lower() not in ["start", "help", "quit"]:
        print("           Please Enter a Valid Command.")
        startChoose = input("           >")
        if startChoose.lower() == "start":
            print("", end="")

        elif startChoose.lower() == "help":
            print("           Player Loaded.")
            menuChoose()

        elif startChoose.lower() == "quit":
            print("           Game End.")
            sys.exit()


def helpMenu(): #the help menu corresponding to the help choice from menu choose.
    print("""\
    \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n
    .-=~=-.                                                                 .-=~=-.
    (__  _)-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-(__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                                                                 (__  _)
    (_ ___)                                                                 (_ ___)
    (__  _)                                                                 (__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                                                                 (__  _)
    (_ ___)                   The Totally Useful Help Menu                  (_ ___)
    (__  _)                                                                 (__  _)
    ( _ __)                              Start                              ( _ __)
    (__  _)                              Help                               (__  _)
    (_ ___)                              Quit                               (_ ___)
    (__  _)                                                                 (__  _)
    ( _ __)                           Version 1.0                           ( _ __)
    (__  _)                                                                 (__  _)
    (_ ___)                                                                 (_ ___)
    (__  _)                                                                 (__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                                                                 (__  _)
    ( _ __)                                                                 ( _ __)
    (__  _)                                                                 (__  _)
    (_ ___)-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-=-._.-(_ ___)
    `-._.-'                                                                 `-._.-'
    """)

    time.sleep(5)
    startMenu()
    menuChoose()


def pickDirection(zoneMap, player): #a function that unables player to navigate around the map
    #by moving up, down, left, or right
    userCurrentLocation = player.getLocation()

    locationInformation = zoneMap[userCurrentLocation]

    validDirection = False

    while validDirection == False:
        playerChoice = input("\nDo you want to move left, right, up, or down?")

        while playerChoice.lower() not in ["left", "right", "up", "down", "quit"]:
            playerChoice = input("Please try again with the correct direction")

        if playerChoice.lower() == "left":

            if locationInformation[LEFT] == None:
                print("You cannot go left from here. Please pick another direction")

            else:
                player.setLocation(locationInformation[LEFT])
                validDirection = True

        elif playerChoice.lower() == "right":
            if locationInformation[RIGHT] == None:
                print("You cannot go right from here. Please pick another direction")

            else:
                player.setLocation(locationInformation[RIGHT])
                validDirection = True

        elif playerChoice.lower() == "up":
            if locationInformation.get(UP) == None:
                print("You cannot go up from here. Please pick another direction")

            else:
                player.setLocation(locationInformation[UP])
                validDirection = True

        elif playerChoice.lower() == "down":
            if locationInformation[DOWN] == None:
                print("You cannot go down from here. Please pick another direction")

            else:
                player.setLocation(locationInformation[DOWN])
                validDirection = True


def battleDetector(userLocation): #this will detect if there are monster in the current location the player is in
    if userLocation[MONSTER] != None:
        return True
    else:
        return False


def printSheetMusic(musicNotes, musicTime): #this will print a certain music from the music library
    for i in range(len(musicNotes)):
        print(musicNotes[i])
        time.sleep(int(musicTime[i])/1000)


def playerDamage(playingNote, userPlayedNote, monster, playerAttack, monsterHP):
    #a function that deals with player attacking monster

    #playerLinesLibrary, what a player says when he successfully hit a monster
    playerLines = ["A blessed beat smites the x for y damage.",
                   "A chilling chord freezes the x for y damage.",
                   "Flaming fortissimo conflagrates the x for y damage.",
                   "Your shocking solo zaps the x for y damage.",
                   "Your gravitational glissando crushes the x for y damage.",
                   "A cursing crescendo cuts the x for y damage.",
                   "The poisonous pianissimo contaminates the x for y damage.",
                   "The deathly dirge withers the x for y damage.",
                   "The eldritch elegy maddens the x for y damage.",
                   "Your transmutational tempo warps the x for y damage.",
                   "The chaotic cadence corrupts the x for y damage.",
                   "An acidic accent melts the x for blank damage.",
                   "Your shadowy sequence smothers the x for y damage.",
                   "A forceful fundamental blasts the x for y damage.",
                   "The psionic pitch crazes the x for y damage.",
                   "Your radiant rhythm roasts the x for y damage.",
                   "The aetherial aria beguiles the x for y damage.",
                   "A metallic melody rusts the x for y damage.",
                   "The radioactive resonance mutates the x for y damage.",
                   "Your stony sharp strikes the x for y damage.",
                   "An arcane anthem pierces the x for y damage.",
                   "Your soulful serenade possesses the x for y damage.",
                   "Your void vibrato atomizes the x for y damage."]

    monsterName = monster.getName()

    if userPlayedNote == playingNote:
        playerLine = random.randint(0, len(playerLines)-1)
        playerLine = playerLines[playerLine]

        playerLine = playerLine.replace("x", monsterName)
        playerLine = playerLine.replace("y", str(playerAttack))

        print(playerLine)
        monsterHP -= playerAttack
        return monsterHP

    else:
        print("You missed!")
        return monsterHP


def findNotePlaying(elapsedTime, musicTime, musicNote): #this function will find the current note
    #that is being printed out by printSheetMusic
    songPlayedTime = 0
    for i in range(len(musicTime)):
        songPlayedTime += int(musicTime[i])
        if elapsedTime < songPlayedTime:
            return musicNote[i]


def levelUp(musicName, player: Person): #this will append a new music that
    # a player can play into his level list, thus indicating that he leveled up.
    musicIndex = len(player.getLevel())
    newMusic = musicName[musicIndex]
    player.addLevel(newMusic)


def gauntletDown(player: Person, userLocation, musicLibrary, zoneMap, musicName):
    #this function deals with player encountering and battling a monster
    pygame.mixer.quit()
    pygame.mixer.init()
    pygame.mixer.music.load("battle.mp3")
    pygame.mixer.music.play()
    monster = userLocation[MONSTER]
    monsterLines = monster.getLines()
    monsterPicture = monster.getPic()

    print("")
    print(monsterPicture)

    print(monsterLines[0])
    print("")

    print(monster.getName(), end = "")
    line = ": " + monsterLines[2]

    for x in range(len(line)):
        print(line[x], end="")
        time.sleep(0.05)
    print("\n")

    print("The Bard " + player.getName(), end="")
    line = ": " + monsterLines[1]

    for y in range(len(line)):
        print(line[y], end="")
        time.sleep(0.05)
    print("\n")

    time.sleep(1)

    #choosing music to battle with
    musicList = player.getLevel()
    for i in range(len(musicList)):
        print(str(i+1) + ": " + musicList[i])

    loopCounter = 0
    while loopCounter == 0:
        try:
            userInput = input("\nChooseth a song to playeth: ")
            pygame.mixer.music.stop()
            pygame.mixer.music.load(userInput + ".mp3")
            pygame.mixer.music.play()
            musicNotes = musicLibrary[userInput][0]
            musicTime = musicLibrary[userInput][1]
            loopCounter = 1
        except pygame.error:
            loopCounter = 0
        except KeyError:
            loopCounter = 0

    sheetMusic = multiprocessing.Process(target=printSheetMusic, args=(musicNotes, musicTime))

    print("\nThee starteth to rememb'r the rhythm of the song", end = "")
    time.sleep(2)
    print(".", end="")
    time.sleep(2)
    print(".", end="")
    time.sleep(2)
    print(".")
    print("Ent'r 'start' to starteth playing")

    #battle start
    monsterHP = monster.getHP()
    playerHP = player.getHP()
    loopCounter = 0
    while loopCounter == 0:
        userInput = input("")
        if userInput.lower() == "start":
            pygame.mixer.music.stop()
            start_time = time.time()
            sheetMusic.start()

        if userInput == "end":
            print("Game End.")
            sheetMusic.terminate()
            break

        try:
            note = userInput[0] + ".mp3"
        except IndexError:
            print("", end="")

        if userInput != "start":
            if len(userInput) == 1:  # sixteenth note
                try:
                    pygame.mixer.music.load(note)
                    pygame.mixer.music.play()
                    pygame.mixer.music.fadeout(800)
                except pygame.error:
                    print("Note not found.")

            elif len(userInput) == 2:  # quarter note
                try:
                    pygame.mixer.music.load(note)
                    pygame.mixer.music.play()
                    pygame.mixer.music.fadeout(1600)
                except pygame.error:
                    print("Note not found.")

            elif len(userInput) == 3:  # 1.5 Quarter note
                try:
                    pygame.mixer.music.load(note)
                    pygame.mixer.music.play()
                    pygame.mixer.music.fadeout(2400)
                except pygame.error:
                    print("Note not found.")

            elif len(userInput) == 4:  # half note
                try:
                    pygame.mixer.music.load(note)
                    pygame.mixer.music.play()
                    pygame.mixer.music.fadeout(3200)
                except pygame.error:
                    print("Note not found.")

            elif len(userInput) == 5:  # whole note
                try:
                    pygame.mixer.music.load(note)
                    pygame.mixer.music.play()
                    pygame.mixer.music.fadeout(6400)
                except pygame.error:
                    print("Note not found.")

            elapsed_time = time.time() - start_time
            elapsed_time = int(round(elapsed_time * float(1000), 0))
            notePlaying = findNotePlaying(elapsed_time, musicTime, musicNotes)
            monsterHP = playerDamage(notePlaying, userInput, monster, player.getAttack(), monsterHP)

        monsterAttack = random.randint(1, 3)
        if monsterAttack == 1:
            playerHP -= monster.getAttack()
            print("")
            monsterSpeakInt = len(monsterLines) - 1
            monsterSpeak = random.randint(3, monsterSpeakInt)
            if monsterSpeak == monsterSpeakInt:
                monsterSpeak = random.randint(3, monsterSpeakInt)
            print(monster.getName()+":" + monsterLines[monsterSpeak])
            print(monster.getName(), "attacked you for", monster.getAttack(), "damages!")

        if monsterHP <= 0:
            print("\nThee wonneth the battleth!")
            print("You remembered to play a new song.")
            levelUp(musicName, player)
            userLocation[MONSTER] = None
            sheetMusic.terminate()
            return userLocation

        elif sheetMusic.is_alive() == False and monsterHP > 0:
            print("\nThou art defeat'd.")
            sheetMusic.terminate()
            userLocation = zoneMap["a1"]
            return userLocation

        elif playerHP <= 0:
            print("\nThou art defeat'd.")
            sheetMusic.terminate()
            userLocation = zoneMap["a1"]
            return userLocation


class Nodes: #nodes for a binary tree
    def __init__(self, data: Person):
        self.parent = None
        self.left = None
        self.right = None
        self.data = data

    def getData(self):
        return self.data

    def setData(self, data: Person):
        self.data = data

    def getDataID(self):
        return self.data.getID()

    def getLeftNode(self):
        return self.left

    def setLeftNode(self, node):
        self.left = node

    def getRightNode(self):
        return self.right

    def setRightNode(self, node):
        self.right = node

    def setParent(self, node):
        self.parent = node


def insertNode(tempParent, InsertNode): #inserting nodes into a binary tree
    if InsertNode.getDataID() < tempParent.getDataID():
        if tempParent.getLeftNode() == None:
            InsertNode.setParent(tempParent)
            tempParent.setLeftNode(InsertNode)
        else:
            insertNode(tempParent.getLeftNode(), InsertNode)

    else:
        if tempParent.getRightNode() == None:
            InsertNode.setParent(tempParent)
            tempParent.setRightNode(InsertNode)
        else:
            insertNode(tempParent.getRightNode(), InsertNode)


def searchNode(parentNode: Nodes, searchID: int): #function to search a node in a binary tree
    if searchID < parentNode.getDataID():
        if parentNode.getLeftNode() == None:
            print("\nPerson not found.")

        elif parentNode.getLeftNode().getDataID() == searchID:
            return parentNode.getLeftNode().getData()

        else:
            searchNode(parentNode.getLeftNode(), searchID)

    elif searchID == parentNode.getDataID():
        return parentNode.getData()

    else:
        if parentNode.getRightNode() == None:
            print("\nPerson not found.")

        elif parentNode.getRightNode().getDataID() == searchID:
            return parentNode.getRightNode().getData()

        else:
            searchNode(parentNode.getRightNode(), searchID)


def saveBinaryTree (root, list): #saving binary trees branch by branch from left to right into a list
    list.append(root.getData())
    if root.getLeftNode() != None:
        saveBinaryTree(root.getLeftNode(), list)
    if root.getRightNode() != None:
        saveBinaryTree(root.getRightNode(), list)
    return list


def updatingNode(parentNode: Nodes, searchID: int, newData: Person): #finds a node and replaces its data
    if searchID < parentNode.getDataID():
        if parentNode.getLeftNode() == None:
            print("\nPerson not found.")

        elif parentNode.getLeftNode().getDataID() == searchID:
            updateLeftNode = parentNode.getLeftNode()
            updateLeftNode.setData(newData)
            parentNode.setLeftNode(updateLeftNode)

        else:
            searchNode(parentNode.getLeftNode(), searchID)

    elif searchID == parentNode.getDataID():
        parentNode.setData(newData)

    else:
        if parentNode.getRightNode() == None:
            print("\nPerson not found.")

        elif parentNode.getRightNode().getDataID() == searchID:
            updateRightNode = parentNode.getRightNode()
            updateRightNode.setData(newData)
            parentNode.setRightNode(updateRightNode)

        else:
            searchNode(parentNode.getRightNode(), searchID)


def readFromFile(userDatabase): #reads all player data from txt file
    f = open("game.txt", "r+")
    data = f.readlines()
    index = 0

    rootID = int(round(len(data)/2))
    rootIndex = -1

    for line in data:

        items = line.split(",")
        userDatabase.append(Person())
        userDatabase[index].setName(items[0])
        userDatabase[index].setHP(int(items[1]))
        userDatabase[index].setID(int(items[2]))
        userDatabase[index].setAttack(int(items[3]))
        list = json.loads(items[4])
        userDatabase[index].setLevel(list)
        userDatabase[index].setLocation(items[5])
        if int(userDatabase[index].getID()) == rootID:
            root = Nodes(userDatabase[index])
            rootIndex = index
        index += 1

    userDatabase.remove(userDatabase[rootIndex])
    f.close()
    return [userDatabase, root]


def writeToFile(userDatabase): #writes player data into a txt file

    f = open("game.txt", "w+")

    for x in range(len(userDatabase)):
        string = json.dumps(userDatabase[x].getLevel())
        f.write(userDatabase[x].getName() + "," + str(userDatabase[x].getHP()) + "," +
                str(userDatabase[x].getID()) + "," + str(userDatabase[x].getAttack()) + "," +
                str(string) + "," + userDatabase[x].getLocation() + "," +"\n")

    f.close()


def listToBinaryTree(userDatabase, root): #transforms a list of playerdata read
    # from the txt file into the binary tree
    for i in range(len(userDatabase)):
        InsertNode = Nodes(userDatabase[i])
        insertNode(root, InsertNode)

    return root


#description for the dictionary of map
AREANAME = "Name"
DESCRIPTION = 'description'
UP = 'up', 'north'
DOWN = 'down', 'south'
LEFT = 'left', 'west'
RIGHT = 'right', 'east'
MONSTER = "instance of class monster"

#monster library that contains information of all monsters
#phoenix
Phoenix = Monster()
Phoenix.setName("The Communist Phoenix")
Phoenix.setHP(400)
Phoenix.setAttack(50)
Phoenix.setLines(["A wild communist phoenix appeared!",
                  "\nWhile fearsome you seem, great flaming bird, \nBehold while I drop you, with naught but a word.",
                  "\nPeace to the People. \nLand to the peasants. \nYour money to me.",
                  "\nThere is not Communism or Marxism, \nbut representative democracy and social justice in a well-planned economy.",
                  "\nThere is no Gulag without you.",
                  "\nYour means of production seems to be your throat.\nI’ll tear it from you; try to then gloat.",
                  "\nThis commie Phoenix seems like quite the meme, \nWhose idea was it? It does not fit the theme."])
Phoenix.setPic(r"""
              _          _
             _/|    _   |\_
           _/_ |   _|\\ | _\
         _/_/| /  /   \|\ |\_\_
       _/_/  |/  /  _  \/\|  \_\_ 
     _/_/    ||  | | \o/ ||    \_\_
    /_/  | | |\  | \_ V  /| | |  \_\
   //    ||| | \_/   \__/ | |||    \\
  // __| ||\  \          /  /|| |__ \\
 //_/ \|||| \/\\        //\/ ||||/ \_\\
///    \\\\/   /        \   \////    \\\
|/      \/    |    |    |     \/      \|
              /_|  | |_  \
             ///_| |_||\_ \
             |//||/||\/||\|             'I SERVE THE SOVIET UNION"
              / \/|||/||/\/                     
                /|/\| \/                            -PHOENIX
                \/  |                          
""")

#dragon
Dragon = Monster()
Dragon.setName("The Dragon")
Dragon.setHP(600)
Dragon.setAttack(60)
Dragon.setLines([
"A wild dragon appeared!",
"\nFierce young dragon, a creature of mesmerizing might. \nWhile no Ancalagon, I still fear this fight.",
"\nI kill where I wish and none dare resist.",
"\nMy armor is like tenfold shields, \nmy teeth are swords, \nmy claws spears, \nthe shock of my tail a thunderbolt, \nmy wings a hurricane, \nand my breath death!",
"\nYou shall die!"
])
Dragon.setPic(r"""
 (  )   /\   _                 (     
    \ |  (  \ ( \.(               )                      _____
  \  \ \  `  `   ) \             (  ___                 / _   \
 (_`    \+   . x  ( .\            \/   \____-----------/ (o)   \_
- .-               \+  ;          (  O                           \____
                          )        \_____________  `              \  /
(__                +- .( -'.- <. - _  VVVVVVV VV V\                 \/
(_____            ._._: <_ - <- _  (--  _AAAAAAA__A_/                  |
  .    /./.+-  . .- /  +--  - .     \______________//_              \_______
  (__ ' /x  / x _/ (                                  \___'          \     /
 , x / ( '  . / .  /                                      |           \   /
    /  /  _/ /    +                                      /              \/
   '  (__/                                             /                  \
""")

#fossegrimen
Fossegrimen = Monster()
Fossegrimen.setName("The Fossegrimen")
Fossegrimen.setHP(550)
Fossegrimen.setAttack(55)
Fossegrimen.setLines([
"A wild fossegrimen appeared!",
"\nIt think it knows music; it thinks it is strong. \nI’ll show it its place; it’s been prey all along.",
"\nTalented you may be, \nyour words coated in honey",
"\nA mortal thinks to best me, \nthis bard is truly funny!",
"\nThy music hast nay rhythm, \nthy attacketh proves bootless!"
])
Fossegrimen.setPic(r"""
                 _..
                    .'   `",
                   ;        \
            .---._; ^,       ;
         .-'      ;{ :  .-. ._;
    .--""          \*'   o/ o/
   /   ,  /         :    _`";
  ;     \;          `.   `"+'
  |      }    /    _.'T"--"\
  :     /   .'.--""-,_ \    ;
   \   /   /_         `,\   ;
    : /   /  `-.,_      \`.  :
    |;   {     .' `-     ; `, \
    : \  `;   {  `-,__..-'   \ `}+=,
     : \  ;    `.   `,        `-,\"
     ! |\ `;     \}?\|}
  .-'  | \ ;
.'}/ i.'  \ `,                           
``''-'    /   \
         /J|/{/
           `'
""")

"""
The Map:

[a1] [a2] [a3]
[b1] [b2] [b3]
[c1] [c2] [c3]
currently only c3, b2, and b3 contains monster
"""
#a dictionary that functions as a map and contains all information of a map
zoneMap = {
    'a1': {AREANAME: "Midgard",
           DESCRIPTION: 'The realm of all us puny mortals, From here to seven realms be portals',
           UP: None, DOWN: 'b1',
           LEFT: None, RIGHT: 'a2',
           MONSTER: None
           },

    'a2': {AREANAME: "Alfheim",
           DESCRIPTION: "Here is a land, once of great cheer and light, Now falling into never ending night,",
           UP: None, DOWN: 'b2',
           LEFT: 'a1', RIGHT: 'a3',
           MONSTER: None
           },

    'a3': {AREANAME: "Nidavellir",
           DESCRIPTION: 'The home of the dwarves, a most stout of folk, Now falling into ruin, ready to croak.',
           UP: None, DOWN: 'b3',
           LEFT: 'a2', RIGHT: None,
           MONSTER: None
           },

    'b1': {AREANAME: "Jotunheim",
           DESCRIPTION: 'The realm of giants, foes ten feet tall. If my luck holds true, I’ll never face them at all.',
           UP: 'a1', DOWN: 'c1',
           LEFT: None, RIGHT: 'b2',
           MONSTER: None
           },

    'b2': {AREANAME: "Svartalfheim",
           DESCRIPTION: 'The home of all the villainous dark elves: a place so dangerous that no one delves.',
           UP: 'a2', DOWN: 'c2',
           LEFT: 'b1', RIGHT: 'b3',
           MONSTER: Phoenix
           },

    'b3': {AREANAME: "Niflheim",
           DESCRIPTION: 'Land of dread and horrifying dead: to pass through I must win through bloodshed.',
           UP: 'a3', DOWN: 'c3',
           LEFT: 'b2', RIGHT: None,
           MONSTER: Fossegrimen
           },

    'c1': {AREANAME: "Vanaheim",
           DESCRIPTION: 'Home of Vanir, the weaker of Gods, against even them, I don’t like my odds.',
           UP: 'b1', DOWN: None,
           LEFT: None, RIGHT: 'c2',
           MONSTER: None
           },

    'c2': {AREANAME: "Asgard",
           DESCRIPTION: 'Plane of Aesir, whose powers amaze and shock, at least they used to, before Ragnorok.',
           UP: 'b2', DOWN: None,
           LEFT: 'c1', RIGHT: 'c3',
           MONSTER: None
           },

    'c3': {AREANAME: "Muspelheim",
           DESCRIPTION: 'Realm of the forces of great and feared Loki, here all must bow before the trickster gods decree',
           UP: 'b3', DOWN: None,
           LEFT: 'c2', RIGHT: None,
           MONSTER: Dragon
           }
}

#main menu music and animation
pygame.mixer.init()
pygame.mixer.music.load("Gilgalad.mp3")
pygame.mixer.music.play()

startAnimation()
startMenu()
menuChoose()

#reading data from txt file into a binary tree
userReadDatabase = []
returnList = readFromFile(userReadDatabase)
userReadDatabase = returnList[0]
highestID = len(userReadDatabase)
root = returnList[1]
root = listToBinaryTree(userReadDatabase, root)
userReadDatabase = None

#load or choose?
print("\n           Load or make a player?")
playerStart = input("           >")

#setting up the player if they choose to make or load
if playerStart.lower() == "make":
    player = Person()
    player.setPlayer(highestID + 2, player)

elif playerStart.lower() == "load":
    playerLoadID = int(input("\n           Enter the player's id to load"
                             "\n           >"))
    player = searchNode(root, playerLoadID)

    introduction = "              On this weary road, I go: a bard, alone and penniless." \
                   "\n              Some would wonder why a bard would ever decide to travel" \
                   "\n              without any support to speak of. " \
                   "\n              While we bards are naturally charming and devilishly handsome, " \
                   "\n              the savages in the Adventurers’ Guild seem to have taken umbrage " \
                   "\n              with my startling humility and thus I must travel alone out into the unknown." \
                   "\n              I will prove all the adventurers wrong when I reach the true heights of power," \
                   "\n              for I seek an artifact of unimaginable strength. " \
                   "\n              f'r i seeketh an artifact of unimaginable pow'r.  " \
                   "\n              I shall travel to the realm of chaos, Muspelheim, where the lore of ancients awaits. " \
                   "\n              My music is strong, but I know not what manner of savagery, sorcery, " \
                   "\n              or skulduggery awaits, and I only hope that I can in time grow strong enough " \
                   "\n              to face the darkest terrors hidden in these ravaged realms. "
    print("\n           The bard " + player.getName() + " says:\n")
    for i in range(len(introduction)):
        print(introduction[i], end="")
        time.sleep(0.03)

print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")

#getting your position on the map
playerLocation = player.getLocation()
playerLocation = zoneMap[playerLocation]
#printing your current location
print("Welcome to the realm of " + playerLocation[AREANAME])
print(playerLocation[DESCRIPTION])
#main game loop
gameRun = 0
while gameRun == 0:
    #choices you can make, move, explore, or quit. the explore function currently does nothing
    print("\nMoveth")
    print("Expl're")
    print("Quit the Quest")
    userInput = input("Which action doth thee wanteth to taketh?")

    while userInput.lower() not in ["moveth", "expl're", "quit"]:
        print("\nMoveth")
        print("Expl're")
        print("Quit the Quest")
        userInput = input("Which action doth thee wanteth to taketh?\n")

    #move to a different part of a map, if there is a monster there, battle.
    if userInput.lower() == "moveth":
        pickDirection(zoneMap, player)
        playerLocation = player.getLocation()
        playerLocation = zoneMap[playerLocation]
        print("")
        print("Welcome to the realm of " + playerLocation[AREANAME])
        print(playerLocation[DESCRIPTION])

        battle = battleDetector(playerLocation)
        if battle == True:
            playerLocation2 = gauntletDown(player, playerLocation, musicLibrary, zoneMap, musicNames)
            if playerLocation[AREANAME] == playerLocation2[AREANAME]:
                zoneMap[player.getLocation()] = playerLocation2
                playerLocation = playerLocation2
            else:
                player.setLocation("a1")
                playerLocation = playerLocation2
        """
        backGroundMusicIndex = random.randint(0, 2)
        pygame.mixer.music.load(backGroundMusic[backGroundMusicIndex]+".mp3")
        pygame.mixer.music.play()
        """

    #explore function that currently does nothing
    elif userInput.lower() == "explore":
        print("")

    #saves player data and write them to a txt file
    elif userInput.lower() == "quit":
        #saving the player
        if playerStart.lower() == "make":
            playerNode = Nodes(player)
            insertNode(root, playerNode)
            userWriteDatabase = []
            userWriteDatabase = saveBinaryTree(root, userWriteDatabase)
            writeToFile(userWriteDatabase)

        elif playerStart.lower() == "load":
            updatingNode(root, playerLoadID, player)
            userWriteDatabase = []
            userWriteDatabase = saveBinaryTree(root, userWriteDatabase)
            writeToFile(userWriteDatabase)

        sys.exit()

